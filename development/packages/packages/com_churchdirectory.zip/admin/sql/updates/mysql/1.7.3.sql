--
-- Version 1.7.3 update
--
INSERT INTO `#__churchdirectory_update` (id,version) VALUES (3,'1.7.3') ON DUPLICATE KEY UPDATE version= '1.7.3';