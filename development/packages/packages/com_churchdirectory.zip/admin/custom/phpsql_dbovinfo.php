<?
 $username = 'nfsda'; // User Name
 $password = ''; // Password
 $database = 'nfsda'; // databes to connect to
 $table = 'goog_qcontacts_kmloptions';
 $server = 'mysql.nfsda.org'; //server to connect to
 $key = 'ABQIAAAA2KlUERY5udeiRITzQu-ChhR4PgILFleQ_YNts3dXMlUtOL449RQt0FiAZ1peZvSM6Jff-SNXbj-ulQ'; // Google Map API Key
 $maps = 'maps.google.com';
 $nfsda_url = 'http://www.nfsda.org';
 $nfsda_img = 'http://www.nfsda.org/custom/logo.png';
?>