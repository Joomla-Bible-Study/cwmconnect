<?php
    	$id = $row["id"];
    	$name = $row["name"];
    	$alias = $row["alias"];
    	$con_posision = $row["con_position"];
    	$address = $row["address"];
    	$suburb = $row["suburb"];
    	$state = $row["state"];
   	$country = $row["contry"];
    	$zip = $row["postcode"];
   	$telephone = $row["telephone"];
   	$fax = $row["fax"];
   	$misc = $row["misc"];
	$image = $row["image"];
   	$email_to = $row["email_to"];
   	$mobile = $row["mobile"];
   	$webpage = $row["webpage"];
   	$skype = $row["skype"];
   	$yahoo_msg = $row["yahoo_msg"];
    	$lat = $row["lat"];
    	$lng = $row["lng"];
   	$team = $row["team"];
   	$teamicon = $row["teamicon"];
?>