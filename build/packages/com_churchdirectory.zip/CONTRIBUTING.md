Contributing to the ChurchDirectory Project
===============
All contributions are welcome to be submitted for review for inclusion in the ChurchDirectory,

Please be patient as not all items will be tested immediately (remember, all bug testing for the ChurchDirectory is done by volunteers) and be receptive to feedback about your code.
