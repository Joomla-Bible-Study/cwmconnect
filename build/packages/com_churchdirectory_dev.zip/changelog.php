<?php
/**
 * Changelog for ChurchDirectory
 *
 * @package    ChurchDirectory.Admin
 * @copyright  (C) 2007 - 2011 Joomla Bible Study Team All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
?>

--1.7.6 April 11, 2013

** New function to search members in admin view by zip "zip:XXXXX"
** Add Male/Female switch not sure what I will use if for in the fucher.
** Add aditional IM field
** Added New Birthday & Anniversery show hide on team view and filter by month.
** New Team Leater System based off the position they hold.


#Fixed problem form cms on serching by authur: in members view.
#Fixed name for admin menu form Unite to Units.
#Fixed pranation in j2.5 view.
#Fixed some menue problems
