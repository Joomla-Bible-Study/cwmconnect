DROP TABLE IF EXISTS `#__churchdirectory_details`;
DROP TABLE IF EXISTS `#__churchdirectory_dirheader`;
DROP TABLE IF EXISTS `#__churchdirectory_familyunit`;
DROP TABLE IF EXISTS `#__churchdirectory_geoupdate`;
DROP TABLE IF EXISTS `#__churchdirectory_kml`;
DROP TABLE IF EXISTS `#__churchdirectory_position`;
DROP TABLE IF EXISTS `#__churchdirectory_update`;
