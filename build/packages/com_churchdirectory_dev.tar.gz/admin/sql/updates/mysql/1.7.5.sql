CREATE TABLE IF NOT EXISTS `#__churchdirectory_geoupdate` (
  `member_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;