ALTER TABLE `#__churchdirectory_details` MODIFY `birthdate` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00';
ALTER TABLE `#__churchdirectory_details` MODIFY `anniversary` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00';
