ALTER TABLE `#__churchdirectory_dirheader` ADD COLUMN `section` TINYINT(3) NOT NULL DEFAULT '0'
COMMENT 'Used to track position on page';
