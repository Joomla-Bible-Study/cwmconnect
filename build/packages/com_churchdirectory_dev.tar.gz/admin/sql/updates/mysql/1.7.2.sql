--
-- Version 1.7.2 update
--
INSERT INTO `#__churchdirectory_update` (id, version) VALUES (2, '1.7.2')
ON DUPLICATE KEY UPDATE version= '1.7.2';
